<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Режим обслуживания';

// Text
$_['text_maintenance'] = 'Режим обслуживания';
$_['text_message']      = '<h1 style="text-align:center;">Магазин временно закрыт: мы выполняем профилактические работы.<br/>Вскоре магазин будет доступен. Пожалуйста, зайдите позже.</h1>';