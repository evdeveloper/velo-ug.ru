<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_subject']	= '%s - отзыв о статье';
$_['text_waiting']	= 'Новые отзывы ожидают вашей проверки.';
$_['text_article']	= 'Статья: %s';
$_['text_reviewer']	= 'Отзыв оставил: %s';
$_['text_rating']	= 'Оценка: %s';
$_['text_review']	= 'Отзыв:';