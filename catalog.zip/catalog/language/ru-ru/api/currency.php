<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_success']     = 'Ваша валюта успешно изменена!';

// Error
$_['error_permission'] = 'Вы не имеете разрешения на доступ к API!';
$_['error_currency']   = 'Код валюты является недействительным!';