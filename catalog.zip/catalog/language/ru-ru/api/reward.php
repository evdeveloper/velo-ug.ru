<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_success']     = 'Бонусные баллы успешно применены!';

// Error
$_['error_permission'] = 'Вы не имеете разрешения на доступ к API!';
$_['error_reward']     = 'Укажите количество бонусных баллов, которые хотите использовать!';
$_['error_points']     = 'У Вас нет %s бонусных баллов!';
$_['error_maximum']    = 'Максимальное количество бонусных баллов, которые могут быть использованы, составляет %s!';