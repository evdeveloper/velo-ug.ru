<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_success']     = 'Ваш купон на скидку успешно применен!';

// Error
$_['error_permission'] = 'Вы не имеете разрешения на доступ к API!';
$_['error_coupon']     = 'Купон либо недействителен, либо истек срок его действия, либо достигнут предел его использования!';