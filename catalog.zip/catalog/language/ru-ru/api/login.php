<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_success'] = 'Сессия API успешно открыта!';

// Error
$_['error_key']    = 'Неверный API ключ!';
$_['error_ip']     = 'Ваш IP %s не имеет доступа к API!';