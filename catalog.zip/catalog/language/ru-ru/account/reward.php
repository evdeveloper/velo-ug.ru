<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']      = 'Бонусные баллы';

// Column
$_['column_date_added']  = 'Дата добавления';
$_['column_description'] = 'Описание';
$_['column_points']      = 'Бонусные баллы';

// Text
$_['text_account']       = 'Личный кабинет';
$_['text_reward']        = 'Бонусные баллы';
$_['text_total']         = 'Накоплено бонусных баллов:';
$_['text_empty']         = 'У Вас нет бонусных баллов!';