<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']    = 'Подписка на новости';

// Text
$_['text_account']     = 'Личный кабинет';
$_['text_newsletter']  = 'Рассылка';
$_['text_success']     = 'Ваша подписка успешно обновлена!';

// Entry
$_['entry_newsletter'] = 'Подписаться';
