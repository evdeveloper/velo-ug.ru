<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Heading
$_['heading_title']     = 'Файлы для скачивания';

// Text
$_['text_account']      = 'Личный кабинет';
$_['text_downloads']    = 'Файлы для скачивания';
$_['text_empty']        = 'Нет доступных файлов для скачивания!';

// Column
$_['column_order_id']   = '№ Заказа';
$_['column_name']       = 'Название';
$_['column_size']       = 'Размер';
$_['column_date_added'] = 'Дата добавления';