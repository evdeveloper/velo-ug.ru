<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_captcha']  = 'Капча';

// Entry
$_['entry_captcha'] = 'Введите код в поле ниже';

// Error
$_['error_captcha'] = 'Неверно введен код с картинки!';
