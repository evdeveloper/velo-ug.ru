<?php
// *	@source		See SOURCE.txt for source and other copyright.
// *	@license	GNU General Public License version 3; see LICENSE.txt

// Text
$_['text_subject']	= '%s - Article Review';
$_['text_waiting']	= 'You have a new article review waiting.';
$_['text_article']	= 'Article: %s';
$_['text_reviewer']	= 'Reviewer: %s';
$_['text_rating']	= 'Rating: %s';
$_['text_review']	= 'Review Text:';