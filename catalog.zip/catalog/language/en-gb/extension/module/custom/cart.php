<?php

$_['heading_cart'] = 'Recycle';

$_['column_image'] = 'Image';
$_['column_name'] = 'Product Name';
$_['column_model'] = 'Model';
$_['column_sku'] = 'Article';
$_['column_quantity'] = 'Number';
$_['column_price'] = 'Price';
$_['column_total'] = 'Total';
$_['column_remove'] = 'Delete';

$_['text_products_total'] = 'Total';

$_['button_update'] = 'Refresh';
$_['button_remove'] = 'Delete';
$_['button_clear']  = 'Clear cart';