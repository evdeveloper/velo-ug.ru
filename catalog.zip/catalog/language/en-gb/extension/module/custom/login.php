<?php

$_['heading_login'] = 'Checkout as';

$_['text_auth'] = 'Already registered';
$_['text_register'] = 'Register';
$_['text_guest'] = 'Guest';
$_['text_forgotten'] = 'Forgot your password?';
$_['text_loading'] = 'Download';
$_['entry_email'] = 'E-mail';
$_['entry_password'] = 'Password';
$_['button_login'] = 'Login';