<?php

$_['heading_comment'] = 'Комментарий к заказу';
$_['entry_comment'] = 'Комментирий';
