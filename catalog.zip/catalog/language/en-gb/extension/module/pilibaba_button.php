<?php
//Heading
$_['heading_title']    = '中国用户请点击Pilibaba按钮跳转至中文页面付款';

//Text
$_['text_description'] = 'Chinese customers please click Pilibaba button to complete checkout';
?>