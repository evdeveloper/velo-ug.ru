<?php

// Heading
$_['page_title'] = 'Checkout';

$_['button_continue'] = 'Continue';

$_['entry_empty']	= 'Cart empty..';

$_['error_module_off'] = 'Enable the module in the settings';
$_['text_loading'] = 'Loading ...';
$_['text_agree'] = 'I have read it and I agree with the document <a href="%s" class="agree"> <b> %s </ b> </a>';