<?php
// Text
$_['text_title']                        = 'Royal Mail';
$_['text_weight']                       = 'Weight:';
$_['text_insurance']                    = 'Insured upto:';
$_['text_special_delivery']             = 'Special Delivery Next Day';
$_['text_1st_class_signed']             = 'First Class Signed Post';
$_['text_2nd_class_signed']             = 'Second Class Signed Post';
$_['text_1st_class_standard']           = 'First Class Standard Post';
$_['text_2nd_class_standard']           = 'Second Class Standard Post';
$_['text_international_standard']       = 'International Standard';
$_['text_international_tracked_signed'] = 'International Tracked & Signed';
$_['text_international_tracked']        = 'International Tracked';
$_['text_international_signed']         = 'International Signed';
$_['text_international_economy']        = 'International Economy';